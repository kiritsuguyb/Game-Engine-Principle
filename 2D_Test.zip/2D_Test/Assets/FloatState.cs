﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloatState : HeroState
{
    public override void HandleInput(Hero hero, OurInput input)
    {
        base.HandleInput(hero, input);
        Quaternion rotation = Quaternion.Euler(0, 0, 0);
        hero.character.transform.localRotation = rotation;
        if (hero.physic.checkOnAir(hero))
        {
            TurnToState(hero, firstJumpState, input);
        }
        if (!input.controlling)
        {
            TurnToState(hero, onEarthState, input);
        }
        if (input.loseHand && !hero.physic.onAir)
        {
            if (vectorIsUpward(input))
            {
                TurnToState(hero, firstJumpState, input);

            }
            input.loseHand = false;
        }
        else
        {
            Vector2 vectorFotRun = input.vector;
            vectorFotRun.y = 0;
            hero.physic.Run(vectorFotRun);
            //hero.physic.moveAccordingToVector;
            if (vectorIsRightward(input))
            {
                Vector3 scale = hero.character.transform.localScale;
                if (scale.x > 0)
                {
                    hero.character.transform.localScale = new Vector3(-scale.x, scale.y, scale.z);
                    //Debug.Log("turnRight");
                }

            }
            if (vectorIsLeftward(input))
            {
                Vector3 scale = hero.character.transform.localScale;
                if (scale.x < 0)
                {
                    hero.character.transform.localScale = new Vector3(-scale.x, scale.y, scale.z);
                    //Debug.Log("turnLeft");
                }
            }
        }
    }
    bool vectorIsUpward(OurInput input)
    {
        return input.vector.y > 0;
    }
    bool vectorIsLeftward(OurInput input)
    {
        return input.vector.x < 0;
    }
    bool vectorIsRightward(OurInput input)
    {
        return input.vector.x > 0;
    }
    public override void Enter(Hero hero, OurInput input)
    {
        base.Enter(hero, input);
        hero.animator.SetBool("isJump", false);
        hero.animator.SetBool("isRush", false);
        hero.animator.SetBool("isRun", true);
        //reIntialize hero.physics to None-Flying
        //or adjust it according to input Data
        //reIntialize hero.animator to OnEarth(like Idling or walking)
    }
    public override void Exit(Hero hero, OurInput input)
    {
        base.Exit(hero, input);
        //start Walking-to-Flying transfer animation or some other effect
        //well notice that this could be done either HERE 
        //Or in the Enter() function of FirstJumpState
    }
    public override void LogState()
    {
        base.LogState();
    }
}
