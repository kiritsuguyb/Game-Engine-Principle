﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(OurInput))]
[RequireComponent(typeof(PhysicSystem))]
[RequireComponent(typeof(HeroState))]
public class Hero : MonoBehaviour
{
    public GameObject character;
    public OurInput input;
    public PhysicSystem physic;
    public HeroState state;
    public Animator animator;
    public float energy = 5;
    [SerializeField]
    float MaxEnergy = 5;
    public float recoverSpeed = 2.5f;
    public float EnergyPercentage=1;
    public GameObject groundCheck;
    public GameObject topCheck;
    public GameObject leftCheck;
    public GameObject rightCheck;

    // Start is called before the first frame update
    void Start()
    {
        state = HeroState.onEarthState;
        state.Enter(GetComponent<Hero>(),input);
        energy = MaxEnergy;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        EnergyPercentage = energy / MaxEnergy;
        state.HandleInput(GetComponent<Hero>(), input);
        //state.LogState();
    }
    public void changeEnergy(float add)
    {
        energy += add;
        if (energy >= MaxEnergy) energy = MaxEnergy;
        if (energy <= 0) energy = 0;
    }
}
