﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    static public float GameTime;
    static public float sceneClearTime = 60f;
    static float startTime;
    // Start is called before the first frame update
    void Start()
    {
        startTime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        GameTime = Time.time - startTime;
        if (GameTime > sceneClearTime) GameTime = sceneClearTime;
    }
}
