﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstJumpState : HeroState
{
    public override void HandleInput(Hero hero, OurInput input)
    {
        base.HandleInput(hero, input);
        Quaternion rotation = Quaternion.Euler(0, 0, 0);
        hero.character.transform.localRotation = rotation;
        if (input.loseHand/*input.Vector is not Empty(松手了)*/)
        {
            TurnToState(hero, airState, input);
            input.loseHand = false;
        }
        if (!hero.physic.checkOnAir(hero))/*如果落地或者碰撞,这里需要hero.physics的数据判断*/
        {
            TurnToState(hero, onEarthState, input);
        }
    }
    public override void Enter(Hero hero, OurInput input)
    {
        base.Enter(hero, input);
        hero.animator.SetBool("isJump", true);
        hero.animator.SetBool("isRush", false);
        hero.animator.SetBool("isRun", false);
        Debug.Log("enter FirstJumpState");
        Vector2 vector2 = input.vector;
        hero.physic.Jump(vector2);
        //reIntialize hero.physics to normal jump state
        //and adjust it according to input Data
        //reIntialize hero.animator to Jump
        //could also do some Walking-to-Flying transfer animation
    }
    public override void Exit(Hero hero, OurInput input)
    {
        base.Exit(hero, input);
        //Nothing to do for now
    }
    public override void LogState()
    {
        base.LogState();
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
