﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AirState : HeroState
{
    Vector2 rushVector;
    float timeZero;
    float timeNow;
    public override void HandleInput(Hero hero, OurInput input)
    {
        base.HandleInput(hero, input);
        timeNow = Time.time - timeZero;
        if (input.loseHand/*input.Vector is not Empty(松手了)*/)
        {
            TurnToState(hero, airState, input);
            input.loseHand = false;
        }
        if (!hero.physic.checkOnAir(hero))
        {
            TurnToState(hero, onEarthState, input);
        }
        hero.physic.Rush(input.vector, timeNow);
        Vector2 velocity = hero.GetComponent<Rigidbody2D>().velocity;
        //Debug.Log("Velocity:  "+velocity.ToString()+"  Degree:  "+ vector2degree(velocity).ToString());
        Quaternion rotation = Quaternion.Euler(0,0,vector2degree(velocity));
        if(velocity.y>0)hero.character.gameObject.transform.rotation = Quaternion.Lerp(hero.character.gameObject.transform.rotation, rotation, Time.deltaTime *30f);
        if (velocity.y <0) hero.character.gameObject.transform.rotation = Quaternion.Lerp(hero.character.gameObject.transform.rotation, rotation, Time.deltaTime*5f );
        if (vectorIsRightward(input))
        {
            Vector3 scale = hero.character.transform.localScale;
            if (scale.x > 0)
            {
                hero.character.transform.localScale = new Vector3(-scale.x, scale.y, scale.z);
                //Debug.Log("turnRight");
            }

        }
        if (vectorIsLeftward(input))
        {
            Vector3 scale = hero.character.transform.localScale;
            if (scale.x < 0)
            {
                hero.character.transform.localScale = new Vector3(-scale.x, scale.y, scale.z);
                //Debug.Log("turnLeft");
            }
        }
    }
    public override void Enter(Hero hero, OurInput input)
    {
        base.Enter(hero, input);
        timeZero = Time.time;
        float magnitude = input.magnitude;
        if (magnitude > hero.energy) magnitude = hero.energy;
        hero.physic.D = magnitude * input.MaxRangeOut * hero.physic.RushDistanceFactor;
        hero.changeEnergy(-input.magnitude);
        Debug.Log("enter AirState");
        hero.animator.SetBool("isJump", false);
        hero.animator.SetBool("isRush", true);
        hero.animator.SetBool("isRun", false);
        ////小明实现冲刺
        //rushVector = input.vector*100;
        //hero.physic.Rush(rushVector);
        //每次空中弹跳都是有一个过程的，弹跳过后就开始掉落
        //因此每次刷新空中状态都要重新设置物理系统然后做动作。
    }
    public override void Exit(Hero hero, OurInput input)
    {
        base.Exit(hero, input);
        //Nothing to do for now
    }
    public override void LogState()
    {
        base.LogState();
    }
    float vector2degree(Vector2 vector)
    {
        vector = vector.normalized;
        float tan = vector.y / Mathf.Abs(vector.x);
        float rad = Mathf.Atan(tan)/(2*Mathf.PI)*360;
        if (vector.x < 0) rad *= -1;
        return rad;
    }
    bool vectorIsLeftward(OurInput input)
    {
        return input.vector.x < 0;
    }
    bool vectorIsRightward(OurInput input)
    {
        return input.vector.x > 0;
    }
}
