﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OurInput : MonoBehaviour
{
    public Vector2 vector;
    public bool loseHand;
    public Vector3 begin;
    public Vector3 end;
    public float MaxRangeIn = 100;
    public float MinRangeIn = 10;
    public float MaxRangeOut = 100;
    public float magnitude = 10;
    public bool controlling = false;
    // Start is called before the first frame update
    void Start()
    {
        loseHand = false;
        vector = Vector2.zero;
        begin = Vector3.zero;
        end = Vector3.zero;
    }

    // Update is called once per frame
    void Update()
    {
        controlling = false;
        //模拟鼠标滑动的输入
        if (Input.GetMouseButtonDown(0))
        {
            begin = Input.mousePosition;
            controlling = true;
        }
        if (Input.GetMouseButton(0))
        {
            end = Input.mousePosition;
            Vector3 temp = end - begin;
            vector = new Vector2(temp.x, temp.y);
            if (vector.magnitude > MaxRangeIn) vector = vector.normalized * MaxRangeIn;
            if(vector.magnitude< MinRangeIn) vector = vector.normalized * MinRangeIn;
            vector /= MaxRangeIn;
            magnitude = vector.magnitude;
            controlling = true;
        }
        if (Input.GetMouseButtonUp(0))
        {
            loseHand = true;
            controlling = true;
        }
        if (loseHand) StartCoroutine(cancelLoseHand());
        //if (loseHand) Debug.Log("loseHand");
    }
    IEnumerator cancelLoseHand()
    {
        yield return new WaitForSeconds(0.1f);
        loseHand = false;
    }
}
