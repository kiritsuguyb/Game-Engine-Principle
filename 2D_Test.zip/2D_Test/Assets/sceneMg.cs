﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sceneMg : MonoBehaviour
{
    public float GameTime;
    public float sceneClearTime = 200f;
    float startTime;
    // Start is called before the first frame update
    void Start()
    {
        startTime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        GameTime = Time.time - startTime;
    }
}
