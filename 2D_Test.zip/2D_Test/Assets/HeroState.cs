﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroState : MonoBehaviour
{
    public virtual void HandleInput(Hero hero,OurInput input) {
        if (hero.physic.stuckInEarth(hero))
        {
            Debug.Log("stuckInEarth");
            hero.physic.Jump(Vector2.up*hero.physic.JumpSpeed);
        }
        if (hero.physic.onGround(hero))
        {
            hero.changeEnergy(hero.recoverSpeed * Time.deltaTime);
        }
    }
    public virtual void Enter(Hero hero, OurInput input) { }//用于初始化
    public virtual void Exit(Hero hero, OurInput input) { }//相当于析构
    public virtual void LogState() {
    }//相当于析构
    public void TurnToState(Hero hero, HeroState state,OurInput input)
    {
        hero.state.Exit(hero,input);
        hero.state = state;
        //Debug.Log(state.GetType().ToString());
        hero.state.Enter(hero,input);
    }
    static public OnEarthState onEarthState=new OnEarthState();
    static public FirstJumpState firstJumpState=new FirstJumpState();
    static public AirState airState=new AirState();
    static public RunState runState = new RunState();
    static public FloatState floatState = new FloatState();

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
