﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationControl : MonoBehaviour
{
    // Start is called before the first frame update
    public Animator ani;
    void Start()
    {
        ani = GameObject.Find("MainCharacter").GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.F1))
        {
            ani.SetFloat("isRun",2.0f);
        }

        if (Input.GetKeyDown(KeyCode.F2))
        {
            ani.SetFloat("isRun", 0.0f);
        }
    }
}
