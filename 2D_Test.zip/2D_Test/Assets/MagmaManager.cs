﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagmaManager : MonoBehaviour
{
    public Transform sceneTop;
    public Transform sceneBottom;
    public GameObject magma;
    public float speedCurveFactor=1;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 pos = magma.transform.position;
        pos.y = sceneBottom.position.y + (sceneTop.position.y - sceneBottom.position.y) * Mathf.Pow(GameManager.GameTime / GameManager.sceneClearTime, speedCurveFactor);
        magma.transform.position=pos;
    }
}
