﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysicSystem : MonoBehaviour
{
    public float t1 = 0.1f;
    public float t2 = 1f;
    public float D = 50;
    public float a = 0.5f;
    public float b = 5;
    public float JumpSpeed = 100;
    public float RunSpeed = 100;
    public float RushGravityFactor= 15;
    public float RushDistanceFactor = 2;
    public float caculateVelocity(float n)
    {
        float velocity = 0;
        if (n > 0 && n < t1)
        {
            velocity =Mathf.Pow((n / t1),a);
        }
        if (n >= t1 && n <= t2)
        {
            velocity = 1 -Mathf.Pow((n - t1) / (t2 - t1),1 / b);
        }
        float c = t1 / (a + 1) + t2 - t1 - (t2 - t1) / (1 / b + 1);
        return velocity = velocity / c * D;
    }
    public float caculateAccelerate(float n,float deltatime)
    {
        float a1= caculateVelocity(n);
        float a0 = caculateVelocity(n - deltatime);
        if (a0 == 0 || a1 == 0) return 0;
        return a1 - a0;
    }
    //奔跑、跳跃、我不停歇！
    public void Run(Vector2 vector2)
    {
        GetComponent<Rigidbody2D>().velocity = vector2* RunSpeed;
    }
    public void Jump(Vector2 vector2)
    {
        vector2.x *= 0.5f * JumpSpeed;
        vector2.y = JumpSpeed;
        GetComponent<Rigidbody2D>().velocity = vector2;
        //Debug.Log("Jump");
    }
    //每帧调用的冲刺
    public void _Rush(Vector2 vector2)
    {
        //Vector3 vector3 = new Vector3(transform.position.x + vector2.x, transform.position.y + vector2.y, transform.position.z);
        //GetComponent<Rigidbody2D>().MovePosition(vector3);
    }

    public bool rush = false;
    //冲刺
    public void Rush(Vector2 vector2,float n)
    {
        //float time = Mathf.Sqrt(vector2.x * vector2.x + vector2.y * vector2.y);
        //StartCoroutine(Rushing(time * 0.01f,vector2));
        float v = caculateVelocity(n);
        Vector2 freefallV = new Vector2(0, -Physics2D.gravity.magnitude * n)* RushGravityFactor;
        if (v > 0.1f)
        {
            //Debug.Log("freefallV=" + freefallV.ToString()+ "   gravity.magnitude:" + Physics2D.gravity.magnitude.ToString());
            GetComponent<Rigidbody2D>().velocity = v * vector2.normalized + freefallV;
            
        }
    }

    //判断冲刺距离
    IEnumerator Rushing(float time,Vector2 vector)
    {
        rush = true;
        if (time > 0.15f)
            time = 0.15f;
        yield return new WaitForSeconds(time);
        rush = false;
        //冲刺末尾的缓冲效果
        Jump(vector .normalized* 60);
        Jump(new Vector2(0, 25));
    }


    //我命由我不由天，天上地上我说了算
    public bool onAir = false;
    public bool onGround(Hero hero)
    {
        bool O = Physics2D.Linecast(transform.position, hero.groundCheck.transform.position, 1 << LayerMask.NameToLayer("Ground"));
        return O;
    }
    public bool onTop(Hero hero)
    {
        bool O = Physics2D.Linecast(transform.position, hero.topCheck.transform.position, 1 << LayerMask.NameToLayer("Ground"));
        return O;
    }
    public bool onRight(Hero hero)
    {
        bool O = Physics2D.Linecast(transform.position, hero.rightCheck.transform.position, 1 << LayerMask.NameToLayer("Ground"));
        return O;
    }
    public bool onLeft(Hero hero)
    {
        bool O = Physics2D.Linecast(transform.position, hero.leftCheck.transform.position, 1 << LayerMask.NameToLayer("Ground"));
        return O;
    }
    public bool checkOnAir(Hero hero)
    {
        return !onLeft(hero) && !onRight(hero) && !onTop(hero) && !onGround(hero);
    }
    public bool stuckInEarth(Hero hero)
    {
        return (onLeft(hero) && onRight(hero)) ||( onTop(hero) && onGround(hero));
    }
    //判断当前是否在空中的状态
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer== LayerMask.NameToLayer("Ground"))
            onAir = false;

    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer == LayerMask.NameToLayer("Ground"))
            onAir = false;
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer == LayerMask.NameToLayer("Ground"))
            onAir = true;
    }
}
