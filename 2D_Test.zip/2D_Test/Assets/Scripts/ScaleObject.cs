﻿using UnityEngine;

public class ScaleObject : MonoBehaviour
{    
    /// <summary>
    /// 该函数实现物体尺寸随鼠标滑动距离而改变
    /// </summary>
    /// <param name="tf">受体</param>
    /// <param name="originalPos">初始世界坐标</param>
    /// <param name="targetPos">目标世界位置</param>
    /// <param name="initScale">初始尺寸</param>
    /// <param name="maxScale">最大尺寸</param>
    /// <param name="maxDistance">允许尺寸变化的最大滑动长度</param>
    public void scaleObjectByMouse(GameObject obj, Vector3 originalPos, Vector3 targetPos, Vector3 initScale, Vector3 maxScale, float maxDistance)
    {
        float distance = Vector2.Distance(originalPos, targetPos);

        if (distance < maxDistance)
        {
            float ratio = distance / maxDistance;
            obj.transform.localScale = Vector3.Lerp(initScale, maxScale, ratio);
        }
    }
}
