﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ArrowSpawner : MonoBehaviour
{
    // 起始圆
    public Image circle;

    // 箭头
    public Image arrow;

    public OurInput input;
    

    [Header("箭头初始尺寸")]
    public Vector3 initScale = new Vector3(0, 0, 0);

    [Header("箭头最大尺寸")]
    public Vector3 maxScale = new Vector3(1f, 2f, 0);
    [Header("箭头最小尺寸")]
    public Vector3 minScale = new Vector3(0.7f, 1f, 0);

    [Header("箭头达到最大尺寸时的滑动距离")]
    public float maxDistance = 1.5f;
    

    // Update is called once per frame
    void Update()
    {
        if (input.controlling)
        {
            circle.enabled = true;
            arrow.enabled = true;
            Vector2 pos = input.begin;
            pos.x -= Screen.width / 2;
            pos.y -= Screen.height / 2;
            circle.gameObject.GetComponent<RectTransform>().anchoredPosition = pos;
            Debug.Log("ScreenPos: " + input.begin.ToString() + "  pos:" + pos.ToString() + "  anchoredPosition:" + circle.gameObject.GetComponent<RectTransform>().anchoredPosition.ToString());

            Quaternion rotation = Quaternion.Euler(new Vector3(0, 0, vector2degree(input.vector)));
            arrow.rectTransform.localRotation = rotation;
            arrow.rectTransform.localScale = minScale+(maxScale-minScale)* (input.magnitude*input.MaxRangeIn-input.MinRangeIn)/(input.MaxRangeIn-input.MinRangeIn) ;
            Debug.Log("input.vector:  " + input.vector.ToString() + "  Degree:  " + vector2degree(input.vector).ToString());
        }
        else
        {
            circle.enabled = false;
            arrow.enabled = false;
        }
    }

    float vector2degree(Vector2 vector)
    {
        if (vector.magnitude < 0.001) return 0;
        vector = vector.normalized;
        float tan = vector.y / Mathf.Abs(vector.x);
        float rad = Mathf.Atan(tan) / (2 * Mathf.PI) * 360-90;
        if (vector.x < 0) rad *= -1;
        return rad;
    }
    /// <summary>
    /// 此函数获取鼠标位置向2D世界坐标的映射向量
    /// </summary>
    /// <param name="position">鼠标位置</param>
    /// <returns></returns>

    /// <summary>
    /// 此函数实现在鼠标指定位置生成箭头元素
    /// </summary>
    /// <param name="inputMousePos">鼠标初始位置</param>
    public void InstantiateArrow()
    {
        Vector3 screenPos = Input.mousePosition;
        screenPos.z = -Camera.main.transform.position.z;
        Vector3 worldPos= Camera.main.ScreenToWorldPoint(screenPos);
    }

    /// <summary>
    /// 此函数展示箭头在鼠标拖拽位置下的状态
    /// </summary>
    /// <param name="inputMousePos">鼠标滑动点</param>
    public void ShowArrowState()
    {
        // 箭头朝向鼠标
        arrow.transform.up = input.vector;
        // 箭头尺寸随鼠标滑动距离而改变
        float distance = input.magnitude;
        arrow.transform.localScale = Vector3.Lerp(arrow.transform.localScale, input.magnitude* maxScale, Time.deltaTime);
    }

    /// <summary>
    /// 此函数实现在指定存活时间之后，销毁之前创建的箭头元素
    /// </summary>
}
