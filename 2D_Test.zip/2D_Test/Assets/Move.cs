﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    //初始值设置
    public float jumpSpeed;//跳跃距离
    public float moveSpeed;//奔跑速度
    public float rushDegree;//冲刺幅度

    bool onAir;

    bool rush = false;

    bool force = false;


    //Vector2 v = Vector2.zero;

    //这个变量储存鼠标滑动的方向向量
    Vector3 begin;
    Vector3 end;
    Vector2 direction;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //模拟鼠标滑动的输入
        if (Input.GetMouseButtonDown(0))
        {
            begin = Camera.main.ScreenToWorldPoint(Input.mousePosition); 
        }

        if(Input.GetMouseButtonUp(0))
        {
            end = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector3 vector3 = end - begin;
            Vector2 vector2 = new Vector2(vector3.x, vector3.y);
            Rush(vector2);
        }

       // Debug.Log(force);
    }
    private void FixedUpdate()
    {
        if (force)
            GetComponent<Rigidbody2D>().velocity += new Vector2(-2.5f, 0);

        //模拟输入控制
        float movx = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;

        if (movx != 0)
        {
            Vector2 vector2 = new Vector2(movx, 0);
            Run(vector2);
        }

        if (Input.GetKeyDown(KeyCode.W) && !onAir)
        {
            Vector2 vector2 = new Vector2(movx * 40, jumpSpeed);
            Jump(vector2);
        }
        if (rush)
            _Rush(direction * rushDegree);
    }

    //每帧调用的冲刺
    public void _Rush(Vector2 vector2)
    {
        Vector3 vector3 = new Vector3(transform.position.x + vector2.x, transform.position.y + vector2.y, transform.position.z);
        GetComponent<Rigidbody2D>().MovePosition(vector3);
    }

    //冲刺
    public void Rush(Vector2 vector2)
    {
        direction = vector2.normalized;
        float time = Mathf.Sqrt(vector2.x * vector2.x + vector2.y * vector2.y);
        StartCoroutine(Rushing(time * 0.01f));
    }

    //判断冲刺距离
    IEnumerator Rushing(float time)
    {
        rush = true;
        if (time > 0.15f)
            time = 0.15f;
        yield return new WaitForSeconds(time);
        rush = false;
        //冲刺末尾的缓冲效果
        Jump(direction * 60);
        Jump(new Vector2(0, 25));
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Force")
            force = true;
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Force")
            force = false;
    }

    //判断当前是否在空中的状态
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "platform")
            onAir = false;
        
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.collider.tag == "platform")
            onAir = false;
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.tag == "platform")
            onAir = true;
    }



    
    //跳跃
    public void Jump(Vector2 vector2)
    {
        GetComponent<Rigidbody2D>().velocity += vector2;
    }

    //奔跑
    public void Run(Vector2 vector2)
    {
        //Vector3 vector3 = new Vector3(transform.position.x + vector2.x, transform.position.y + vector2.y, transform.position.z);
        //GetComponent<Rigidbody2D>().MovePosition(vector3);
        transform.Translate(vector2);
    }


}
